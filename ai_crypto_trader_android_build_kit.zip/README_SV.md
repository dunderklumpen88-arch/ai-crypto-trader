# Bygg AI Crypto Trader som Android-APK

Detta är ett byggpaket för en enkel Android-app som öppnar den befintliga AI Crypto Trader-panelen.

## Viktigt innan APK byggs
Render-startsidan visade JSON i stället för instrumentpanelen. APK:n öppnar Render-adressen, så fixa först `root()` i `main.py` så att den returnerar `index.html` (instruktionerna finns i chatten). Testa att `https://ai-crypto-trader-f8cz.onrender.com/` visar panelen, inte JSON.

Appen är avsedd för PAPER ONLY. Den här Android-wrappern skickar inga egna tradingorder; den visar bara befintliga webbpanelen. Behåll `real_orders_enabled: false`.

## Filer
- `android-app/` — Android-projektet.
- `.github/workflows/android-apk.yml` — bygger APK i GitHub Actions.

## Så får du APK:n
1. På datorn: ladda ner och packa upp ZIP-filen.
2. Kopiera mappen `android-app` och mappen `.github` till roten av GitHub-repot `dunderklumpen88-arch/ai-crypto-trader`. Behåll mapparna och filstrukturen.
3. Commit/pusha filerna till `main`.
4. Öppna fliken **Actions** i GitHub.
5. Välj **Build Android APK**, tryck **Run workflow** om den inte startar automatiskt.
6. Öppna den färdiga körningen, scrolla till **Artifacts** och ladda ner `ai-crypto-trader-debug-apk`.
7. Packa upp artefakten och installera `app-debug.apk` på Android. Android kan fråga om tillåtelse att installera appar från webbläsaren/filer.

Om GitHub Actions inte går att köra behöver repoägaren kontrollera att Actions är aktiverat i repo-inställningarna.

## Byggstatus
Detta ZIP är byggkällkod och ett GitHub Actions-workflow, inte en redan kompilerad APK. APK-filen skapas av GitHub Actions efter att filerna lagts in i repot.
