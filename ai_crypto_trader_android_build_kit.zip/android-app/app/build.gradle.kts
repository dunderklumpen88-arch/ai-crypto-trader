plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "se.aicryptotrader.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "se.aicryptotrader.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
